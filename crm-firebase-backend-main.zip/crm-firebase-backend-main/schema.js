let db = {
  users: [
    {
      userHandle: 'user',
      body: 'this is the user body and is not required',
      createdAt: '"2021-08-28T08:59:18.823Z"',
      userName: 'string',
      email: 'email',
      firstName: 'fname',
      lastName: 'lname',
    },
  ],
};
